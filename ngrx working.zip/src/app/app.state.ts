import { Demo } from "./modal/demo.modal";

export interface AppState {
    readonly demoStore: Demo[];
}