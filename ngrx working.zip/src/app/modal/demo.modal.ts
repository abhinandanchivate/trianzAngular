export interface Demo {
    name: string
    gender: string
}