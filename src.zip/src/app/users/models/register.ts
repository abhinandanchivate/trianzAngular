export class Register {
  name: string;
  email: string;
  password: string;
  password2: string;
  /// can we declare the multiple constructor?
  // it will allow to ddeclare only one constructor
  // we can declare the constructor using the word constructor

 
}
