import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-edu-display',
  templateUrl: './dashboard-edu-display.component.html',
  styleUrls: ['./dashboard-edu-display.component.css']
})
export class DashboardEduDisplayComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
