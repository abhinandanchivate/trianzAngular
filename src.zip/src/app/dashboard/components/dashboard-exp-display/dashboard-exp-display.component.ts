import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-exp-display',
  templateUrl: './dashboard-exp-display.component.html',
  styleUrls: ['./dashboard-exp-display.component.css']
})
export class DashboardExpDisplayComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
